# Instructional Design Capacity Planner

A static, client-side capacity calculator for instructional design staffing and course development workload.

## Deploy to GitHub Pages

1. Create a new GitHub repository, e.g. `id-capacity-planner`.
2. Upload `index.html` (and optionally this README) to the **root** of the repository.
3. Open **Settings > Pages**. Under **Build and deployment**, select **Deploy from a branch**, branch `main`, folder `/ (root)`, then **Save**.
4. Once published, visit `https://YOUR-USERNAME.github.io/id-capacity-planner/`.

No build process, dependencies, or server are required. You can also open `index.html` locally.

## Features

- Four editable staffing roles: ID, Senior ID, ID Manager, Associate ID
- Adjustable course development percentages, project effort, reserve, and other commitments
- Vacancy scenario for the combined ID role
- Real-time development FTE, concurrent project capacity, and utilization
- CSV export and copyable summary

## Important

The default staff counts and project effort are **illustrative**, not a verified UT staffing roster. The combined ID allocation (80%) and Senior ID allocation (70%) are editable assumptions. Review before using the results for staffing decisions.

This app does not send data to a server or save inputs between visits. A public GitHub Pages site is publicly accessible; avoid embedding confidential employee or workload information in the repository.
